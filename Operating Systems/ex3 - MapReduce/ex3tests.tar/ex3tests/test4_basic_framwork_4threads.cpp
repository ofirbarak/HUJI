#include <iostream>
#include "MapReduceClient.h"
#include "MapReduceFramework.h"

class elements : public k1Base,public k2Base,public k3Base,public v1Base,public v2Base,public v3Base
{
public:

    elements(int i){num = i;}

    bool operator<(const k1Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    bool operator<(const k2Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    bool operator<(const k3Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    bool operator<(const v1Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    bool operator<(const v2Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    bool operator<(const v3Base &other) const
    {
        return num < dynamic_cast< const elements &>(other).num;
    }

    int num;
};

class tester : public MapReduceBase
{
public:

    virtual void Map(const k1Base *const key, const v1Base *const val) const
    {
	int input = (((elements*)key)->num)%50;
        

        Emit2(new elements(input),new elements(1));
        
        delete key;
        delete val;
    }

    virtual void Reduce(const k2Base *const key, const V2_VEC &vals) const
    {
        Emit3(new elements(((elements*)key)->num),new elements((int)vals.size()));
    }
};

/**
 * @brief The main function running the program.
 */
int main(int argc, char *argv[])
{
    std::vector<int> numbers(50, 0);

    std::srand(100000);
    int i;
    int modulu_val;
    tester s;
    IN_ITEMS_VEC in_items_vec;
    for (int j = 0; j < 1000000; ++j)
    {
        i = std::rand();
	    modulu_val = i % 50;
        numbers[modulu_val]++;

        in_items_vec.push_back(std::pair<k1Base *, v1Base *>(new elements(i), NULL));
    }

    OUT_ITEMS_VEC result = RunMapReduceFramework(s, in_items_vec, 4, true);

    for (int j=0; j < result.size(); j++)
    {
        int value = ((elements *)result[j].second)->num;
        std::cout<< value <<std::endl;
    }

    for (int k = 0; k < result.size(); k++)
    {
        delete result[k].first;
        delete result[k].second;
    }

    return 0;
}
