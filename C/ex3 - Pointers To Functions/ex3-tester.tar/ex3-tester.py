import sys
import os
import subprocess

# usage: python3 ex3-tester.py path/to/program path/to/testsDir

programPath = sys.argv[1]
testsDir = sys.argv[2]

filenames = os.listdir(testsDir)

valgrindOutput = open("valgrind.out", 'w')
valgrindProgram = "valgrind"
singleValOut = "singleVal.out"
valgrindFlags = ["--leak-check=full", "--show-possibly-lost=yes", "--show-reachable=yes",
                 "--undef-value-errors=yes", "--log-file="+singleValOut]


for name in filenames:
    if name[-2:] == "in":
        with open(testsDir+"/"+name) as file:
            arguments = (file.readline())[:-1]

            fullCommand = [valgrindProgram] + valgrindFlags + [programPath]+ arguments.split()

            process = subprocess.Popen(fullCommand, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, stdin=subprocess.PIPE,
                                       universal_newlines=True)
            stdout_data, stderr_data = process.communicate(timeout=1)

            with open(testsDir+"/"+name[:-2]+"out") as expectedResultFile:
                expectedResult = expectedResultFile.read()
                if expectedResult != stdout_data:
                    print("mismatched output for test ", name[:-2])
                else:
                    print("test ", name[:-2], " OK")

            singleVal = open("singleVal.out")
            for line in singleVal:
                valgrindOutput.write("    ----    valgrind result for test "+ name[:-2] + "    ----    \n\n")
                valgrindOutput.write(singleVal.read())
                valgrindOutput.write("\n"*3)

os.remove(singleValOut)
